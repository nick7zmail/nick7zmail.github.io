const s="/assets/map.d2b37c28.png";export{s as _};
