const s="/assets/Mi_Gateway_Shield12.4ac3c49d.jpg";export{s as _};
