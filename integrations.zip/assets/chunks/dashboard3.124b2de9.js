const s="/assets/dashboard4.a7f00375.jpg",a="/assets/dashboard41.b6711c7d.jpg",o="/assets/dashboard3.5455ab82.jpg";export{s as _,a,o as b};
