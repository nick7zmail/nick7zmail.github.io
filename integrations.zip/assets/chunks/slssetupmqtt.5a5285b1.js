const s="/assets/slshome.17a31bee.png",t="/assets/slssetupmqtt.1a71633f.png";export{s as _,t as a};
