const s="/assets/koridor.ec75591e.png",a="/assets/int_ha_discovery.c03a7a60.png";export{s as _,a};
